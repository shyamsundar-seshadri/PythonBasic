"""
    A Date class with
    __init__ : Initializer
    display : method
    __str__ : used by print
    __repr__ : used by repr
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

class Date:
    def __init__(self, d=1, m=1, y=1970):
        self.dd, self.mm, self.yy = d, m, y

    def display(self):
        return f"{self.dd}-{self.mm}-{self.yy}"

    def __str__(self):
        return f"{self.dd}/{self.mm}/{self.yy}"

    def __repr__(self):
        return f"Date({self.dd}, {self.mm}, {self.yy})"

# Main
today = Date(18, 7, 2018)
#x = today.display()
print(today.display())
print(today) # This invokes __str__
print(repr(today)) # This invokes __repr__

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
