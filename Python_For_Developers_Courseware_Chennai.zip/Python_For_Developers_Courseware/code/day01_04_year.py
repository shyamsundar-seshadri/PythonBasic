"""
    A Python program that prompts the user for the year they were born in
    It calculates the user's age 10 years from now [ 2019 ]
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

year = input("When were you born ? ")
year = int(year)
# Comment the above line to get the below error message
# TypeError: unsupported operand type(s) for -: 'int' and 'str'

age = 2019 - year
print("You will be", age + 10, "years old after 10 years")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
