"""
    Sort the numbers that are present in a file
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

with open("numbers.txt") as FH:
    intlist = list()
    for line in FH:
        x = int(line)
        intlist.append(x)

print("Sorted numbers :", sorted(intlist))

# One liner using sorted function

print(sorted([ int(x) for x in open("numbers.txt").read().split() ]))

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
