'''
    Using map function
'''
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

names = ["Anil", "Sunil", "Vishal", "Shekhar"]
ids = range(1, 5)

# zip is used to iterate over multiple lists in parallel
print(list(zip(ids, names))) # List of tuples
'''
    The above line prints
    [(1, 'Anil'), (2, 'Sunil'), (3, 'Vishal'), (4, 'Shekhar')]
'''

print(dict(zip(ids, names))) # Dictionary with all ids as keys and all names as values
'''
    The above line prints
    {1: 'Anil', 2: 'Sunil', 3: 'Vishal', 4: 'Shekhar'}
'''

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
