'''
    Print the names of captains and the number of matches they played
    Print the names first by sorting based on captain names
    Then print the names showing the captain with highest matches played first
'''

captains = dict()
with open("captains.txt") as FH:
    headers = next(FH) # A neat trick to skip the first header line
    for line in FH:
        parts = line.split(',')
        name = parts[0]
        matches = int(parts[2])
        captains[name] = matches

# Printing the captains information sorted based on names
for name in sorted(captains): # sorted returns keys sorted alphabetically
    print(f"{name:>30} : {captains[name]:>4}")
else:
    print("-" * 45)

# Printing the captains information sorted based on matches they played
for name in sorted(captains, key=captains.get, reverse=True): 
    # sorted returns keys sorted by matches played
    print(f"{name:>30} : {captains[name]:>4}")

