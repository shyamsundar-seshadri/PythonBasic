"""
    Difference between sort and sorted
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

names = ["Ajay", "Sam", "Mahesh", "Vijendra", "Dinesh" ]

sorted_names = sorted(names)
print("Sorted alphabetically")
print(sorted_names)

print("Original names")
print(names)

# This modifies the original list itself
names.sort() # In-place and does not return a new sorted list
print("Sorted using sort() method")
print(names)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
