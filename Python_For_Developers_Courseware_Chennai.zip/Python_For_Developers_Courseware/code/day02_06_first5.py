"""
    print the first 5 lines of a file
    print the last 5 lines of a file
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

# Print first 5 lines of a file
with open("captains.txt") as FH:
    counter = 0
    # Fetch the first line
    headers = next(FH)
    for line in FH:
        print(line.split(',')[0])
        counter += 1
        if counter == 5:
            break

print("-" * 25)
# Print last 5 lines of a file
with open("captains.txt") as FH:
    # Fetch the first line
    headers = next(FH)
    all_text = FH.read()
    all_lines = all_text.split('\n')
    for line in all_lines[-5:]:
        print(line.split(',')[0])

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
