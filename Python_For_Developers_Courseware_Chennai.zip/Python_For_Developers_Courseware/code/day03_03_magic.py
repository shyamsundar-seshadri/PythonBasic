"""
    Using an empty list as a default parameter
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

def fun(a = 0):
    print(a + 10)

# Main
fun(5)    # prints 15
fun(10)   # prints 20
fun()     # prints 10
fun()     # prints 10
fun()     # prints 10

# The initialisation of a happens at compile time
def magic(a = []):
    a.append(10)
    print(a)

# Main
magic([1, 2, 3])  # prints [1, 2, 3, 10]
x = [4, 5]
magic(x)          # prints [4, 5, 10]
magic(x)          # prints [4, 5, 10, 10]
magic()           # prints [10]
magic()           # prints [10, 10]
magic()           # prints [10, 10, 10]

# Fixes the problem
def another(a = None):
    if a == None:
        a = []
    a.append(10)
    print(a)

# Main
another([1, 2, 3])  # prints [1, 2, 3, 10]
x = [4, 5]
another(x)          # prints [4, 5, 10]
another(x)          # prints [4, 5, 10, 10]
another()           # prints [10]
another()           # prints [10]
another()           # prints [10]

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
