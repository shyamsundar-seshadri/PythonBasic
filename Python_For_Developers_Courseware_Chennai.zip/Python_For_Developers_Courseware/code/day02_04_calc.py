"""
    Using __name__ for creating modules
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

def add(x, y):
    return x + y

def sub(x, y):
    return x - y

# Main
if __name__ == "__main__":
    a = 10
    b = 20
    c = add(a, b)
    print("Sum", c)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
