"""
    Understanding list slicing
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

a = [1, 2, 3, 4, 5]
print(f"a : {a}")

# Assigning a to b, simply adds a new reference to the same memory
b = a
print(f"b : {b}")

print(f"a == b results in {a == b}")
print(f"a is b results in {a is b}")

# Both a and b will refer to the same memory location
print(f"a is at: {id(a)}")
print(f"b is at: {id(b)}")

# Any modification done through a should be visible from b
a[0] = 30
print(f"a : {a}")
print(f"b : {b}")

# Creating a slice of a
aa = a[1:4]
print(f"aa : {aa}")

# Changes done in aa are not visible through a, since aa uses separate memory
aa[0] = 25
print(f"aa : {aa}")
print(f"a : {a}")
print(f"b : {b}")

print(f"a  is at: {id(a)}")
print(f"b  is at: {id(b)}")
print(f"aa is at: {id(aa)}")

# Create a full slice of a [ in a separate memory ]
c = a[:]
print(f"a : {a}")
print(f"c : {c}")

print(f"a  is at: {id(a)}")
print(f"c  is at: {id(c)}")

# Changes done in c are not visible through a, since c uses separate memory
c[2] = 99
print(f"c : {c}")
print(f"a : {a}")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
