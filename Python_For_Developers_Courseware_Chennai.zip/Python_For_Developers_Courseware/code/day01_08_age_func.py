"""
    Modify the age program to use a function to print the age
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

def find_age(birth_year, present):
    age = present - birth_year
    print("You will be", age + 10, "years, 10 years from now")

year = input("Enter the year you were born in : ")
year = int(year)
find_age(year, 2019)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
