"""
    Sorting a list using sorted and key
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

names = ["Ajay", "Sam", "Mahesh", "Vijendra", "Dinesh" ]

sorted_names = sorted(names)
print("Sorted alphabetically")
print(sorted_names)

sorted_len_names = sorted(names, key=len)
print("Sorted by length of the name")
print(sorted_len_names)

def my_param(x):
    return len(x)

sorted_len_names = sorted(names, key=my_param)
print("Sorted by length of the name")
print(sorted_len_names)

def my_param(x):
    return x[-1]

sorted_len_names = sorted(names, key=my_param)
print("Sorted by last character of the name")
print(sorted_len_names)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
