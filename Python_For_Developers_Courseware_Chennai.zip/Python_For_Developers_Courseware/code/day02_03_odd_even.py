"""
    Printing odd numbers using a for loop
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

# Print all odd numbers from 120 to 150
for num in range(121, 150, 2):
    print(num, end=" ")

print("-" * 25)
# For all two digit numbers, print their half their value
# For all three digit numbers, print double their value
for num in range(94, 109):
    if num < 100:
        print(num/2)
    else:
        print(num * 2)

print("-" * 25)
# Printing 2.2 as 2.20
x = 2.2
print(f"{x}") # This prints 2.2
print(f"{x:.2f}") # This prints 2.20

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
