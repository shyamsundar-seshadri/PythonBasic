"""
    A Python program to print, 
        directory name
        filename and
        file extension
    from a given Unix like path
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

path = "/home/apple/Downloads/story.txt.gz"
parts = path.split('/')
filename = parts[-1]
print("File name", filename)

idx = filename.find('.')
print("Full File extension", filename[idx+1:]) # This prints all characters after first dot

parts_new = filename.split('.')
ext = parts_new[-1]
print("File extension", ext) # This prints the last extension

directory = "/".join(parts[:-1])
print("Directory", directory)

'''
    The above code will print :
    File name story.txt.gz
    Full File extension txt.gz
    File extension gz
    Directory /home/apple/Downloads
'''
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
