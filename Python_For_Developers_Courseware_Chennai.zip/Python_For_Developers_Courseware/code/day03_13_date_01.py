"""
    Simple class with
    __init__ : initializer
    display : to display information
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

class Date:
    def __init__(self, d=1, m=1, y=1970):
        self.dd = d
        self.mm = m
        self.yy = y

    def display(self):
        print(self.dd)
        print(self.mm)
        print(self.yy)

# Main
today = Date(18, 7, 2018)
today.display()

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
