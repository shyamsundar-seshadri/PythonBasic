"""
    Modify find_age() function to now return the age
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

def find_age(birth_year, present):
    res = present - birth_year
    return res

year = input("Enter the year you were born in : ")
year = int(year)
age = find_age(year, 2019)
print("You will be", age + 10, "years, 10 years from now")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
