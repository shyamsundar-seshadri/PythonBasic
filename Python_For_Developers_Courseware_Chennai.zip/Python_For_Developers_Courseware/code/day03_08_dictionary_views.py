"""
    Dictionary views
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

# Understanding the known behaviour of lists
runs = [1, 2, 3, 4, 5]
nruns = len(runs)
print("Number of runs", nruns)
runs.append(10)
# Since we did not re-calculate len(), the below print should also print 5
print("Number of runs", nruns)

scores = {
            "Sachin" : [100, 99],
            "Rohit"  : [120, 34.5],
            "Virat"  : [87, 129.5],
        }

# Dictionary elements are in the same order as they are added
print(f"scores : {scores}")

# Extract and print all the values
print("All values")
vvv = scores.values()
for v in vvv:
    print(v)

# To print an individual value
print(scores['Sachin'][1])

# Extract all the keys
kkk = scores.keys()
print(f"Dict Keys : {kkk}")

# Printing keys as a list
x= list(kkk)
print(f"Keys as list : {x}")

# Iterating a dictionary
for k in kkk:
    print(k)

print('-' * 20)
# Iterating a dictionary using a list of keys
for k in x:
    print(k)

# Adding a new element to the dictionary
# This automatically gets reflected in the dictionary views [ keys ]
scores['Dhoni'] = [200, 321.8]
print(f"Keys as list : {x}")
print(f"Dict Keys : {kkk}")

# Deleting an element of the dictionary
# This also is automatically reflected in dictionary views [ keys ]
del scores['Rohit']
print(f"Keys as list : {x}")
print(f"Dict Keys : {kkk}")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
