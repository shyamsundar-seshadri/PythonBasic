"""
    Use of f-strings
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

fruit = "apples"
cost = 250
quant = 1
price = cost / 12

#print("The cost of 1 {} is {}".format(fruit, price))
#print("The cost of 1 {} is {}".format(fruit[:-1], price))
#print("The cost of 1 {a} is {b}".format(a=fruit[:-1], b=price))
#print("The cost of {fruit} is {price}".format(fruit=fruit[:-1], price=price))
print(f"The cost of 1 {fruit} is {price}")
print(f"The cost of 1 {fruit[:-1]} is {price}")

print(f"The cost of 5 {fruit} is {5 * price}")
print(f"The cost of 5 {fruit} is {5 * price:.2f}")

x = f"The {fruit[:-1].upper()}"
print(x)

print( round(10.2389, 2) ) # This prints 10.24
print( round(10.2389, 0) ) # This prints 10.0
print( round(10.8389, 0) ) # This prints 11.0

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
