"""
    Find the top 10 most frequently occurring words in a novel
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

from collections import Counter

word_freq = Counter()

with open("A_Tale_of_Two_Cities.txt") as FH:
    for line in FH:
        words = line.split()
        word_freq.update(words)

print(word_freq.most_common(10))

""" 
The above code prints the following top 10 most commonly occurring words:

[('the', 7514), ('and', 4745), ('of', 4065), ('to', 3458), 
 ('a', 2825), ('in', 2447), ('his', 1911), ('was', 1673), 
 ('that', 1663), ('I', 1446)]

"""

print(word_freq.most_common(20))
""" 
The above code prints the following top 20 most commonly occurring words:

[('the', 7514), ('and', 4745), ('of', 4065), ('to', 3458), ('a', 2825), ('in',
2447), ('his', 1911), ('was', 1673), ('that', 1663), ('I', 1446), ('he', 1389),
('with', 1288), ('had', 1263), ('it', 1173), ('as', 1016), ('at', 978), ('you',
895), ('for', 868), ('on', 820), ('her', 818)]

"""

print(word_freq.most_common(20)[-5:])
""" 
The above code prints the following top 15 to 20 most commonly occurring words:

[('at', 978), ('you', 895), ('for', 868), ('on', 820), ('her', 818)]

"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
