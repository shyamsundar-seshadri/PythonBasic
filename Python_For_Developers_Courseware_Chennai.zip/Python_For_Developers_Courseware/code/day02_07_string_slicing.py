"""
    Understanding string slicing
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

x = "Hello"
print(f"x : {x}")

# Assigning x to y, simply adds a new reference to the same memory
y = x
print(f"y : {y}")

print(f"x == y results in {x == y}")
print(f"x is y results in {x is y}")

# Both x and y will refer to the same memory location
print(f"x is at: {id(x)}")
print(f"y is at: {id(y)}")

# Creating a slice of x
xx = x[1:4]
print(f"xx : {xx}")

# A string slices is created in a separate memory location [ mostly ]
print(f"x  is at: {id(x)}")
print(f"y  is at: {id(y)}")
print(f"xx is at: {id(xx)}")

# Create a full slice of x
z = x[:]
print(f"x : {x}")
print(f"z : {z}")

print(f"x  is at: {id(x)}")
print(f"y  is at: {id(y)}")
print(f"z  is at: {id(z)}")
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
