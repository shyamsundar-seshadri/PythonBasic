"""
    Dictionary views
"""
# Copyright 2018 Sarfraaz Ahmed. All rights reserved.


scores = {
            "Sachin" : 100,
            "Virat"  : 80,
            "Dhoni"  : 90
        }

# Dictionary elements are in the same order as they are added
print(f"scores : {scores}")

# Extract all the keys
kkk = scores.keys()
print(f"Dict Keys : {kkk}")

# Printing keys as a list
x= list(kkk)
print(f"Keys as list : {x}")

# Iterating a dictionary
for k in kkk:
    print(k)

print('-' * 20)
# Iterating a dictionary using a list of keys
for k in x:
    print(k)

# Adding a new element to the dictionary
# This automatically gets reflected in the dictionary views [ keys ]
scores['Rohit'] = 75
print(f"Keys as list : {x}")
print(f"Dict Keys : {kkk}")

# Deleting an element of the dictionary
# This also is automatically reflected in dictionary views [ keys ]
del scores['Dhoni']
print(f"Keys as list : {x}")
print(f"Dict Keys : {kkk}")
# Copyright 2018 Sarfraaz Ahmed. All rights reserved.
