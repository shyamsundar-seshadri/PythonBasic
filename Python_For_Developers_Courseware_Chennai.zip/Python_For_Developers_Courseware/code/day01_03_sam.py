"""
    An interactive program to prompt the user for their name and wish them Hello
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

name = input("Enter your name ")
print("Hello", name, "!!!")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
