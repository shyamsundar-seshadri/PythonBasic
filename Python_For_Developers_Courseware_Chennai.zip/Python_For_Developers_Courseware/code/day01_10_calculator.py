"""
    Python program to explain using functions to solve problems
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

def add(x, y):
    res = x + y
    return res

def sub(x, y):
    res = x - y
    return res

# Main
a = 10
b = 20
c = add(a, b)
print("Sum is ", c)
d = sub(a, b)
print("Diff is", d)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
