"""
    Count the number of words in a file
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

with open("story.txt") as FH:
    words = 0
    for line in FH:
        words += len(line.split())

print("Total words :", words)

# One liner using sum function

print(sum([ len(line.split()) for line in open("story.txt") ]))

# Count the number of words that contain 'a'
with open("story.txt") as FH:
    ayes = 0
    for line in FH:
        words = line.split()
        for w in words:
            if 'a' in w:
                ayes +=1

print("Words with a :", ayes)

# One liner using sum function

print(sum([ 1 for line in open("story.txt") for w in line.split() if 'a' in w ]))

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
