'''
    Use of lambda functions
'''
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

a = lambda x : x + 10

# The above lambda function is same as the below function n()
def n(x):
    return x + 10

print(a(10)) # Prints 20
print(n(10)) # Prints 20

# A lambda function with 2 inputs
b = lambda x,y : x + y
print(b(10, 20)) # Prints 30

# A lambda function to calculate age of a person
age = lambda birth_year : 2019 - birth_year
print(age(2000))

from datetime import datetime # Used to fetch the current year from the system
age = lambda birth_year : datetime.today().year - birth_year
print(age(2000))

# A lambda function that does not take any input
c = lambda : "Hello World"
print(c()) # Prints Hello World

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
