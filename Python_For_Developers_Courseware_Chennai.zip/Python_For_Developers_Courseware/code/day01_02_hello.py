"""
    A simple Python program that prints : Hello World
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

print("Hello", "World")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
