"""
    Find the number of hours, days, months and years
    Sandeep will take to travel 10,000 kms
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

Total = 10_000 # New Python style introduced from 3.6

effort = input("How mamy kms can you travel every day ? ")

days = Total // int(effort) # To do integer division use // instead of /
hours = Total % int(effort)

months = days // 30
days = days % 30

years = months // 12
months = months % 12

print(years, "years", months, "months", days, "days", hours, "hours")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
