"""
    A Python program that explains how to return a value from a function
    add_2() is a simple function that takes a number as input
        and return the given number + 2
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.


def add_2(x):
    res = x + 2
    return res

y = add_2(10)
print(y)

'''
    The above code will print :
    12
'''
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
