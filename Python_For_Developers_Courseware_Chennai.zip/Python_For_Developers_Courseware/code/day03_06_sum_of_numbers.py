"""
    Find the sum of numbers present in a file
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

with open("numbers.txt") as FH:
    total = 0
    for line in FH:
        x = int(line)
        total += x

print("Total :", total)

# Another way using sum() function
with open("numbers.txt") as FH:
    text = FH.read()
    nums = text.split()
    intlist = [ int(x) for x in nums ]
    print(f"Sum : {sum(intlist)}")

# One liner using sum function

print(sum([ int(x) for x in open("numbers.txt").read().split() ]))

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
