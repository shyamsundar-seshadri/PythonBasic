"""
    Anamolies of removing items from a list
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

nums = [1, 23, 345, 2, 456, 789, 537, 34, 882, 99]

print(f"There are {len(nums)} items in nums")
print(nums)

# Remove all 3 digit numbers
for item in nums:
    if item > 99:
        nums.remove(item)

print("After removing 3 digit numbers")
print(nums)

# Never modify the list that you are iterating over

# The correct way to remove elements from a list
# is to iterate over a copy of the original list
for item in nums[:]:
    if item > 99:
        nums.remove(item)

print("After removing 3 digit numbers")
print(nums)
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
