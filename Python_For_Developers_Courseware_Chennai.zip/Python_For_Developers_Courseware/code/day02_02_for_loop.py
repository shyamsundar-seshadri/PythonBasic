"""
    Iterative over a string using a for loop
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

sent = "Chennai is the capital city of Tamil Nadu"

# The below for loop will fetch one character in every iteration
for ch in sent:
    print(ch)

print("-" * 25)
# The below for loop will fetch one word in every iteration
for word in sent.split():
    print(word)

print("-" * 25)
# Print only those words that contain 'a'
for word in sent.split():
    if 'a' in word:
        print(word)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
