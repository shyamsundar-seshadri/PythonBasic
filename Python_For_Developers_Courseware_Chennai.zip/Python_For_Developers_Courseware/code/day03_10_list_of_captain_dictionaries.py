'''
    Create a dictionary that represents each captain.
    Create a list of such dictionaries
    Print captain information sorted based on their names
    Print captain information sorted based on the number of matches they played
    Find the win percentage of each captain
    Print the names of captains and the number of matches they won
'''
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

#Load the captain informatio into a list of dictionaries
#Each dictionary representing one captain
all_caps = list()
with open("captains.txt") as FH:
    headers = next(FH)
    for line in FH:
        captain = dict()
        parts = line.split(',')
        name = parts[0]
        #mat = parts[2]
        #won = parts[3]
        #lost = parts[4]
        #mat, won, lost = [int(x) for x in parts[2:5]]
        mat, won, lost = map(int, parts[2:5])
        captain['name'] = name
        captain['played'] = mat
        captain['wins'] = won
        captain['lost'] = lost
        all_caps.append(captain)

# Print the names of captains and the number of matches they won
for cap_dict in all_caps:
    print(f"{cap_dict['name']:>20} : {cap_dict['wins']:>4}")
else:
    print("*" * 30)

def getname(x):
    """
        Callback function for sorted
        This returns the 'name' value for a given dictionary
    """
    return x['name']

def getplayed(x):
    """
        Callback function for sorted
        This returns the 'played' value for a given dictionary
    """
    return x['played']

# Print captain information sorted based on their names
for cap_dict in sorted(all_caps, key=lambda x:x['name']):
    print(f"{cap_dict['name']:>20} : {cap_dict['played']:>4} {cap_dict['wins']:>4} {cap_dict['lost']:>4}")
else:
    print("*" * 30)


# Print captain information sorted based on the number of matches they played
for cap_dict in sorted(all_caps, key=getplayed):
    print(f"{cap_dict['name']:>20} : {cap_dict['played']:>4} {cap_dict['wins']:>4} {cap_dict['lost']:>4}")
else:
    print("*" * 30)

# Calculate win percentage for each captain
for cap_dict in all_caps:
    cap_dict['winPerc'] = 100 * cap_dict['wins'] / cap_dict['played']

def getwinperc(x):
    """
        Callback function for sorted
        This returns the 'winPerc' value for a given dictionary
    """
    return x['winPerc']

# Print captain information sorted based on their win percentage
for cap_dict in sorted(all_caps, key=getwinperc, reverse=True):
    print(f"{cap_dict['name']:>20} : {cap_dict['played']:>4} {cap_dict['wins']:>4} {cap_dict['winPerc']:>4.2f}")
else:
    print("*" * 30)

# Let's ignore all those captains that have captained for less than 5 matches

#exp_capts = [x for x in all_caps if x['played'] > 5]
exp_capts = [x for x in all_caps if x['played'] > 6] # more than 6 matches

# Print captain information sorted based on their win percentage
for cap_dict in sorted(exp_capts, key=getwinperc, reverse=True):
    print(f"{cap_dict['name']:>20} : {cap_dict['played']:>4} {cap_dict['wins']:>4} {cap_dict['winPerc']:>4.2f}")
else:
    print("*" * 30)

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
