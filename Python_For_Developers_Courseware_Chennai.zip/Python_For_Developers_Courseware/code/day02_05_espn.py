"""
    Imports add() and sub() functions from calc module
    Rename day02_04_calc.py as calc.py to make this work
    Also, this program *cannot* be run from IDLE
    It accepts command line input, and so *should* be
    executed from command prompt [ C:\> ] only
"""
# Copyright 2019 Sarfraaz Ahmed. All rights reserved.

import sys
from calc import add, sub

aus1 = sys.argv[1]
aus1 = int(aus1)

ind1 = int(sys.argv[2])
aus2 = int(sys.argv[3])

aus_total = add(aus1, aus2)
ind2 = sub(aus_total, ind1)
target = add(ind2, 1)
print(f"India needs {target} runs to win the match")

# Copyright 2019 Sarfraaz Ahmed. All rights reserved.
